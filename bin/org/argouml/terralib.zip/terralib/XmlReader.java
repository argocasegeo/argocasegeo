/** "Porque Deus amou o mundo de tal maneira que deu o seu filho unig�nito para
 que todo aquele que nele cr� n�o pere�a, mas tenha a vida eterna". Jo. 3:16*/

// @author Alexandre Gazola
// �ltima atualiza�ao em 05/11/2004

package org.argouml.terralib;

import java.io.*;
import java.net.*;
import java.util.*;
import javax.xml.parsers.*;
import org.w3c.dom.*; 
import javax.swing.*;

import javax.swing.JOptionPane;
import java.util.LinkedList;


public class XmlReader {

  // caminho (path) do arquivo XML
  private String xmlPathname;
  // objeto que manipular� o BD
  private TerraDatabase terraDB;
  // diret�rio de gera�ao do BD
  private String directory;
  // janela de dados �teis
  private Dbms window;

  // construtor que seta o caminho do XML
  public XmlReader(String path) {
       JFrame m = new JFrame();
      window = new Dbms(m);
      directory = window.getDir();;
      if( directory.equals(""))
      {
          directory = "./";
          return;
      }
          
    xmlPathname = path; 
        
  }
 
  // le o XML carregando os dados dos usu�rios em um Vector.
  // retorna o vector contendo os usu�rios cadastrados no XML.
  public void lerXMI() throws Exception { 
  
    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    DocumentBuilder db = dbf.newDocumentBuilder();
    
   Document doc = null;
   
    try{
    doc = db.parse( xmlPathname );  
    }
    catch( Exception e)
    { System.out.println("exce�ao aqui!" + e);}
   
    
    // pega a raiz do documento XML
    Element elem = doc.getDocumentElement();
    
    // pega todos os Modelos do XML, os quais representar�o bancos de dados diferentes
    NodeList nl = elem.getElementsByTagName( "Model_Management.Model" );
    
    // Assumindo apenas 1 banco de dados
    Element model = (Element)nl.item(0); // colocar �ndice gen�rico********
    
    String database = getChildTagValue(model, "Foundation.Core.ModelElement.name");
       
    // Escolhe o banco de dados que ser� utilizado
    int opcao = window.getBD(); 
    
    // cria o banco de dados
    terraDB = new TerraDatabase(database, directory, opcao);
    
        
    // packages cont�m todos os pacotes do modelo
    // pacotes ser�o mapeados em vistas num banco TerraLib
    NodeList packages = model.getElementsByTagName( "Model_Management.Package" );
    
     // armazena nome da classe e sua chave prim�ria(nessa ordem)
    List auxiliary = new ArrayList(); // voltar isso para dentro do for do pacote qualquer coisa
       
    for( int npack = 0; npack < packages.getLength(); npack++ )
    {
    Element pack = (Element)packages.item(npack); // **********colocar �ndice gen�rico
    String view = getChildTagValue(pack, "Foundation.Core.ModelElement.name");
    
    
    // guarda os objetos geogr�ficos deste pacote
    NodeList geoobjs = pack.getElementsByTagName( "Foundation.Core.GeographicObject" );
    // guarda os objetos n�o-geogr�ficos deste pacote
    NodeList ngeoobjs = pack.getElementsByTagName( "Foundation.Core.NonGeographicObject" );
    // guarda os campos geogr�ficos
    NodeList geofields = pack.getElementsByTagName( "Foundation.Core.GeographicField" );
    // guarda as associa��es
    NodeList associations = pack.getElementsByTagName( "Foundation.Core.Association" );
    // guarda as generaliza��es
    NodeList generalizations = pack.getElementsByTagName( "Foundation.Core.Generalization" );
    
   
    
    // armazena as classes que possuem especializa�oes
    List specialization = new ArrayList();
 
    //********* manipula�ao dos objetos geogr�ficos*************
    String[] themes = new String[geoobjs.getLength()];
    for( int i = 0; i < geoobjs.getLength(); i++ )
    {
        Element geoobj = (Element)geoobjs.item(i);
        String nome = getChildTagValue( geoobj, "Foundation.Core.ModelElement.name" );
    
        NodeList list = geoobj.getElementsByTagName("Foundation.Core.GeneralizableElement.specialization");
        if( list.getLength() > 0)      
            specialization.add(nome);    
        
        NodeList genera = geoobj.getElementsByTagName("Foundation.Core.GeneralizableElement.generalization");
        NodeList especia = geoobj.getElementsByTagName("Foundation.Core.GeneralizableElement.specialization");
        if( (genera.getLength() > 0) || (especia.getLength() > 0) )  
        {            
            themes[i] = "";
            continue;
        }
               
          // insere este layer no banco de dados
          terraDB.addLayer(nome);
          themes[i] = nome;       
          
        // verifica as representa�oes do objeto
       boolean isPoint, isLine, isPolygon, isComplexObj;
       isPoint = checkRepresentation( geoobj, "isPoint");
       isLine = checkRepresentation( geoobj, "isLine");
       isPolygon = checkRepresentation( geoobj, "isPolygon");
       isComplexObj = checkRepresentation( geoobj, "isComplexObj" );
       
      
       
       // inser�ao das representa�oes dos objetos geogr�ficos no banco de dados
  
       String[] representation = new String[4];
       representation[0] = representation[1]= representation[2]= representation[3] = "";
       
       if (isPoint) representation[0] = "Ponto";
       if (isLine)  representation[1] = "Linha";
       if (isPolygon) representation[2] = "Pol";
       if (isComplexObj) representation[3] = "Complex";
       
       terraDB.addLayerRep( nome, representation);      
        
        
       // atributos
       NodeList attributes = geoobj.getElementsByTagName( "Foundation.Core.Attribute" );
       String[] attList = new String[2 * (attributes.getLength())];
       String primaryKey = "";
            
       int controle = 0;
       for( int j = 0; j < attributes.getLength(); j++ )
       {
           
           Element attr = (Element)attributes.item(j);
           // nome do atributo
           String attributeName = getChildTagValue( attr, "Foundation.Core.ModelElement.name" );
           
           attList[controle] = attributeName;
                     
           NodeList structFields = attr.getElementsByTagName("Foundation.Core.StructuralFeature.type");
           Element structType = (Element)structFields.item(0);
        
           NodeList classifiers = structType.getElementsByTagName( "Foundation.Core.Classifier" );
           Element classify = (Element)classifiers.item(0);
           // tipo do atributo 
           String attrID = classify.getAttribute("xmi.idref");
           String attributeType = getType( model, attrID );    
           
           attList[controle + 1] = attributeType;
           
           // chave prim�ria ou n�o
           boolean pKey = false;
           NodeList pKeys = attr.getElementsByTagName( "Foundation.Extension_Mechanisms.TaggedValue" );
           for( int k = 0; k < pKeys.getLength(); k++ )
           {
               Element temp = (Element)pKeys.item(k);
               String teste = getChildTagValue( temp, "Foundation.Extension_Mechanisms.TaggedValue.tag" );
               String teste2 = getChildTagValue(temp, "Foundation.Extension_Mechanisms.TaggedValue.value");
               if (teste.equals("primary key")&& teste2.equals("true") )
               {
                   pKey = true;
               }
           }
           
           if( pKey ) primaryKey = attributeName;
          
           // trecho necess�ria para os relacionamentos
           if( pKey )
           {
               auxiliary.add(nome);
               auxiliary.add(attributeName);          
           }
                     
           controle += 2;
                   
           
       }
       
    
          //acrescenta atributos ao banco de dados
         terraDB.addAttr( nome, attList, primaryKey );          
            
    }    
    
    // cria a view adicionando os temas( pr�prios layers )
    if(geoobjs.getLength()> 0)
       terraDB.addViewTheme(view, themes );
     
     //************* fim da manipula�ao dos objetos geogr�ficos*************
     
     // *********** manipula�ao dos objetos n�o-geogr�ficos *****************//
     // Neste caso, s� teremos tabelas de atributos     
     
    
    for( int i = 0; i < ngeoobjs.getLength(); i++ )
    {
        Element ngeoobj = (Element)ngeoobjs.item(i);
        String nome = getChildTagValue( ngeoobj, "Foundation.Core.ModelElement.name" );
  
        
         NodeList list = ngeoobj.getElementsByTagName("Foundation.Core.GeneralizableElement.specialization");
        if( list.getLength() > 0)      
            specialization.add(nome);           
        
        NodeList genera = ngeoobj.getElementsByTagName("Foundation.Core.GeneralizableElement.generalization");
        NodeList especia = ngeoobj.getElementsByTagName("Foundation.Core.GeneralizableElement.specialization");
        if( (genera.getLength() > 0) || (especia.getLength() > 0) )  
        {            
            themes[i] = "";
            continue;
        }
        
        
         // atributos
       NodeList attributes = ngeoobj.getElementsByTagName( "Foundation.Core.Attribute" );
       String[] attList = new String[2 * (attributes.getLength())];
       String primaryKey = "";
       int controle = 0;
        
       for( int j = 0; j < attributes.getLength(); j++ )
       {
           
           Element attr = (Element)attributes.item(j);
           // nome do atributo
           String attributeName = getChildTagValue( attr, "Foundation.Core.ModelElement.name" );
           
           attList[controle] = attributeName;
                     
           NodeList structFields = attr.getElementsByTagName("Foundation.Core.StructuralFeature.type");
           Element structType = (Element)structFields.item(0);
        
           NodeList classifiers = structType.getElementsByTagName( "Foundation.Core.Classifier" );
           Element classify = (Element)classifiers.item(0);
           // tipo do atributo 
           String attrID = classify.getAttribute("xmi.idref");
           String attributeType = getType( model, attrID );    
           
           attList[controle + 1] = attributeType;
           
           // chave prim�ria ou n�o
           boolean pKey = false;
           NodeList pKeys = attr.getElementsByTagName( "Foundation.Extension_Mechanisms.TaggedValue" );
           for( int k = 0; k < pKeys.getLength(); k++ )
           {
               Element temp = (Element)pKeys.item(k);
               String teste = getChildTagValue( temp, "Foundation.Extension_Mechanisms.TaggedValue.tag" );
               String teste2 = getChildTagValue(temp, "Foundation.Extension_Mechanisms.TaggedValue.value");
               if (teste.equals("primary key")&& teste2.equals("true") )
               {
                   pKey = true;
               }
           }
           
       
           if( pKey ) primaryKey = attributeName;
           
            // trecho necess�ria para os relacionamentos
           if( pKey )
           {
               auxiliary.add(nome);
               auxiliary.add(attributeName);          
           }
          
           
           controle += 2;
       }
       
       terraDB.addTable( nome, attList, primaryKey);
       
    }
     //************* fim da manipula�ao dos objetos n�o-geogr�ficos*************  
     
     // *********** manipula�ao dos campos geogr�ficos *****************//
     
    themes = new String[geofields.getLength()];   
    for( int i = 0; i < geofields.getLength(); i++ )
    {
        Element geofieldobj = (Element)geofields.item(i);
        String nome = getChildTagValue( geofieldobj, "Foundation.Core.ModelElement.name" );
        
         NodeList list = geofieldobj.getElementsByTagName("Foundation.Core.GeneralizableElement.specialization");
        if( list.getLength() > 0)      
            specialization.add(nome);    
           
        NodeList genera = geofieldobj.getElementsByTagName("Foundation.Core.GeneralizableElement.generalization");
        NodeList especia = geofieldobj.getElementsByTagName("Foundation.Core.GeneralizableElement.specialization");
        if( (genera.getLength() > 0) || (especia.getLength() > 0) )  
        {            
            themes[i] = "";
            continue;
        }
        
          // insere este layer no banco de dados
          terraDB.addLayer(nome);
          themes[i] = nome;       
          
        // verifica as representa�oes do objeto
       boolean isGridOfCels, isAdjPolygons, isIsolines, isGridOfPoints, isTIN, isIrregularPoints;
       isGridOfCels = checkRepresentation( geofieldobj, "isGridOfCels");
       isAdjPolygons = checkRepresentation( geofieldobj, "isAdjPolygons");
       isIsolines = checkRepresentation( geofieldobj, "isIsolines");
       isGridOfPoints = checkRepresentation( geofieldobj, "isGridOfPoints" );
       isTIN = checkRepresentation( geofieldobj, "isTIN");
       isIrregularPoints = checkRepresentation( geofieldobj, "isIrregularPoints");
       
       // inser�ao das representa�oes dos objetos geogr�ficos no banco de dados
  
       String[] representation = new String[6];
       representation[0] = representation[1]= representation[2]= representation[3] = "";
       representation[4] = representation[5] = "";
       
       if (isGridOfCels) representation[0] = "Celula";
       if (isAdjPolygons)  representation[1] = "Pol";
       if (isIsolines) representation[2] = "Linha";
       if (isGridOfPoints) representation[3] = "Ponto";
       if (isTIN) representation[2] = "Pol";
       if (isIrregularPoints) representation[3] = "Ponto";
       
       
       terraDB.addLayerRep( nome, representation);      
        
        
         // atributos
       NodeList attributes = geofieldobj.getElementsByTagName( "Foundation.Core.Attribute" );
       String[] attList = new String[(2 * (attributes.getLength())) + 2] ;
       String primaryKey = "";
       int controle = 0;
        
       for( int j = 0; j < attributes.getLength(); j++ )
       {
           
           Element attr = (Element)attributes.item(j);
           // nome do atributo
           String attributeName = getChildTagValue( attr, "Foundation.Core.ModelElement.name" );
           
           attList[controle] = attributeName;
                     
           NodeList structFields = attr.getElementsByTagName("Foundation.Core.StructuralFeature.type");
           Element structType = (Element)structFields.item(0);
        
           NodeList classifiers = structType.getElementsByTagName( "Foundation.Core.Classifier" );
           Element classify = (Element)classifiers.item(0);
           // tipo do atributo 
           String attrID = classify.getAttribute("xmi.idref");
           String attributeType = getType( model, attrID );    
           System.out.println( attributeType );
           attList[controle + 1] = attributeType;
           
           // chave prim�ria ou n�o
           boolean pKey = false;
           NodeList pKeys = attr.getElementsByTagName( "Foundation.Extension_Mechanisms.TaggedValue" );
           for( int k = 0; k < pKeys.getLength(); k++ )
           {
               Element temp = (Element)pKeys.item(k);
               String teste = getChildTagValue( temp, "Foundation.Extension_Mechanisms.TaggedValue.tag" );
               String teste2 = getChildTagValue(temp, "Foundation.Extension_Mechanisms.TaggedValue.value");
               if (teste.equals("primary key")&& teste2.equals("true") )
               {
                   pKey = true;
               }
           }
                   
       
           if( pKey ) primaryKey = attributeName;
           
            // trecho necess�ria para os relacionamentos
           if( pKey )
           {
               auxiliary.add(nome);
               auxiliary.add(attributeName);          
           }
          
           
           controle += 2;
       }
       
       attList[ (2 * (attributes.getLength())) ] = "Cota";
       attList[ (2 * (attributes.getLength()))  + 1 ] = "String";
       
       //acrescenta atributos ao banco de dados
         terraDB.addAttr( nome, attList, primaryKey );
      
     
    }    
     
     // cria a view adicionando os temas( pr�prios layers )
    if( geofields.getLength() > 0 )
        terraDB.addViewTheme(view, themes );
    //************* fim da manipula�ao dos campos geogr�ficos*************//  
  
    //*************************** RELACIONAMENTOS ************************//
    
    // Associa�ao, Agrega��o e Composi��o    
  
    for( int i = 0; i < associations.getLength(); i++ )
    {
        Element association = (Element)associations.item(i);
              
       if( association.hasAttribute("xmi.id"))
       {     
         
            // ID da classe, many indica se a multiplicidade � de muitos
            // informa��es da primeira classe
            String className1; boolean many1;
            // Informa�oes da segunda classe
            String className2; boolean many2;
            
            // multiplicidades
            NodeList multiplicities = association.getElementsByTagName( "Foundation.Core.AssociationEnd.multiplicity");
            Element multiplicity = (Element)multiplicities.item(0); // pega primeira multiplicidade
            many1 = getMultiplicity( multiplicity, pack );
            multiplicity = (Element)multiplicities.item(1); // pega a segunda multiplicidade
            many2 = getMultiplicity( multiplicity, pack );
               
            // nomedas das classes envolvidas no relacionamento
            NodeList relations = association.getElementsByTagName( "Foundation.Core.AssociationEnd.type");
                   
            Element relation = (Element)relations.item(0); // pega primeira classe
            className1 = getClassName1( relation, pack );
            relation = (Element)relations.item(1); // pega a segunda classe
            className2 = getClassName1( relation, pack );           
             
            
            String pKey = "";
            // Obten�ao das chaves prim�rias das tabelas envolvidas
             Iterator it = auxiliary.iterator();
             while( it.hasNext())
             {   
                 if( className1.equals(it.next()))
                     pKey = (String)it.next();
                 else
                     it.next();
                               
             }              
             
                    
            // tratamento do relacionamento 1 para 1, e 1 para N
            if( ((!many1) && (!many2)) || ((!many1) && (many2))  ) 
            {  System.out.println("passei aqui!");
                // Neste caso, a tabela da classe className1 exporta o campo para a classe className2
                terraDB.createRelation(className1, className1, className2, pKey);           
            }
             
            // tratamento do restante do relacionamento 1 para N
            else if(many1 && (!many2))
            {  System.out.println("passei neste!");
                // Neste caso, a tabela da classe className2 exporta o campo para a classe className1
             Iterator it2 = auxiliary.iterator();
             while( it2.hasNext())
             {   
                 if( className2.equals(it2.next()))
                     pKey = (String)it2.next();
                 else
                     it2.next();
                               
             }              
               
                terraDB.createRelation(className2, className2, className1, pKey);                
            }
             
            // tratamento do relacionamento M para N
            else
            {
                String pKey2 = "";
                it = auxiliary.iterator();
                while( it.hasNext())
                {   
                   if( className2.equals(it.next()))
                       pKey2 = (String)it.next();
                   else
                      it.next();
                }
                if( pKey.equals(""))
                    pKey = "object_id_";
                if( pKey2.equals(""))
                    pKey2 = "object_id_";
                          
                terraDB.createTable(className1, className2, pKey, pKey2 );
                
            }
            
        
       }
    }        
    
    
    // Generaliza��o e Especializa��o    
    GeneraWindow  gWindow;
    int contadores = specialization.size();
     char op;
    if (contadores-- > 0)
    {       
       
        JFrame fr = new JFrame();
        String parentClass = view;      
         gWindow = new GeneraWindow(fr, parentClass);
          op = gWindow.getOp(); // identifica a o tipo de transforma�ao que o usu�rio deseja aplicar
    }    
     
        
    else
        op = 'D';
    String parentClass;
    
           if(op == 'A')
           {
               String primaryKey = "";
               String[] representation;
               Iterator it = specialization.iterator();
               while( it.hasNext() )
               { 
                   parentClass = (String)it.next();
                   primaryKey = getPrimaryKey( parentClass, pack );                
                   List descendants = getDescendant( parentClass, pack );
                    
                   int size = descendants.size();                
                   String[] desc = new String[descendants.size()];
                   desc = (String[])descendants.toArray(new String[0]);
        
                         
                   representation = decideRepresentation(parentClass, desc, pack );
                             
                   List attrs = new ArrayList();
                   attrs = getAttributeList(parentClass, pack, true);
                 
                   for( int i = 0; i < desc.length; i++ )
                   {
                       attrs.addAll(getAttributeList(desc[i], pack, false));
                   }
              
                   
                   String z[] = new String[attrs.size()];
                   z = (String[])attrs.toArray(new String[0]);
                   
                 
                   for( int i = 0; i < z.length; i++ )
                   {
                       System.out.println(z[i]);
                       
                       
                   }
                   
                    System.out.println("primaryKey: " + primaryKey );
                    terraDB.createEspA( parentClass, primaryKey, desc, representation, z, view );           
                                     
                   
               }
               
           }
    
           else if( op == 'B' )
           {               
               
               String primaryKey = "";                             
               String[] representation;
               String[] pkeys;
               Iterator it = specialization.iterator();
               while( it.hasNext() )
               { 
                   parentClass = (String)it.next();
                   // chave da classe base
                   primaryKey = getPrimaryKey( parentClass, pack );
                                                         
                   List descendants = getDescendant( parentClass, pack );
                    
                   int size = descendants.size();                
                   String[] desc = new String[descendants.size()];
                   desc = (String[])descendants.toArray(new String[0]);
        
                   pkeys = new String[desc.length];
                   for( int i = 0; i < desc.length; i++ )
                   {
                       pkeys[i] = getPrimaryKey( desc[i], pack );
                       
                   }
                                        
                   representation = decideRepresentation(parentClass, desc, pack );
                    
                   // armazena chaves das classes filhas
                   String[] descpkeys = new String[desc.length];
                   for( int i = 0; i < descpkeys.length; i++ )
                       descpkeys[i] = getPrimaryKey( desc[i], pack );           
                   
                   
                   // armazena atributos das classe filhas
                   String[][] myAttrs = new String[desc.length][];
                   
                   List attrs = new ArrayList();
                   attrs = getAttributeList(parentClass, pack, true);    
                
                   String parentAttributes[];
                   
                   // armazena atributos da classe base
                   parentAttributes = new String[attrs.size()];
                   parentAttributes = (String[]) attrs.toArray(new String[0]); 
                  
                                     
                   for( int i = 0; i < desc.length; i++ )  
                   {
                       attrs = getAttributeList(desc[i], pack, true);
                       myAttrs[i] = new String[attrs.size()];
                       myAttrs[i] = (String[])(attrs.toArray(new String[0]));
                   }  
                 
                                   
                    terraDB.createEspB( parentClass, primaryKey, parentAttributes, desc, descpkeys, representation, myAttrs, view );             
               }
                             
           }
    
           else if( op == 'C' )
           {
               
               String primaryKey = "";                             
               String[] representation;
               String[] pkeys;
               Iterator it = specialization.iterator();
               while( it.hasNext() )
               { 
                   parentClass = (String)it.next();
                   // chave da classe base
                   primaryKey = getPrimaryKey( parentClass, pack );
                                                         
                   List descendants = getDescendant( parentClass, pack );
                    
                   int size = descendants.size();                
                   String[] desc = new String[descendants.size()];
                   desc = (String[])descendants.toArray(new String[0]);
                             
                   representation = decideRepresentation(parentClass, desc, pack );
                    
                   // armazena chaves das classes filhas
                   String[] descpkeys = new String[desc.length];
                   for( int i = 0; i < descpkeys.length; i++ )
                       descpkeys[i] = getPrimaryKey( desc[i], pack );           
                   
                   
                   // armazena atributos das classe filhas
                   String[][] myAttrs = new String[desc.length][];
                   
                   List attrs = new ArrayList();
                   attrs = getAttributeList(parentClass, pack, true);    
                
                   String parentAttributes[];
                   
                   // armazena atributos da classe base
                   parentAttributes = new String[attrs.size()];
                   parentAttributes = (String[]) attrs.toArray(new String[0]); 
                  
                                     
                   for( int i = 0; i < desc.length; i++ )  
                   {
                       attrs = getAttributeList(desc[i], pack, true);
                       myAttrs[i] = new String[attrs.size()];
                       myAttrs[i] = (String[])(attrs.toArray(new String[0]));
                   }  
                 
                                   
                    terraDB.createEspC( parentClass, primaryKey, parentAttributes, desc, descpkeys, representation, myAttrs, view );             
                         
               
               } 
           }
    
    }
    // TRATAMENTO DAS ASSOCIA��ES INTER-PACOTES
    // Associa�ao, Agrega��o e Composi��o    
  
    NodeList interAssociations = model.getElementsByTagName( "Foundation.Core.Association" );
     
    for( int i = 0; i < interAssociations.getLength(); i++ )
    {
        Element interAssociation = (Element)interAssociations.item(i);
              
       if( interAssociation.hasAttribute("xmi.id"))
       {     
         
            // ID da classe, many indica se a multiplicidade � de muitos
            // informa��es da primeira classe
            String className1; boolean many1;
            // Informa�oes da segunda classe
            String className2; boolean many2;
            
            // multiplicidades
            NodeList multiplicities = interAssociation.getElementsByTagName( "Foundation.Core.AssociationEnd.multiplicity");
            Element multiplicity = (Element)multiplicities.item(0); // pega primeira multiplicidade
            many1 = getMultiplicity( multiplicity, model );
            multiplicity = (Element)multiplicities.item(1); // pega a segunda multiplicidade
            many2 = getMultiplicity( multiplicity, model );
               
            // nomedas das classes envolvidas no relacionamento
            NodeList relations = interAssociation.getElementsByTagName( "Foundation.Core.AssociationEnd.type");
                   
            Element relation = (Element)relations.item(0); // pega primeira classe
            className1 = getClassName1( relation, model );
            relation = (Element)relations.item(1); // pega a segunda classe
            className2 = getClassName1( relation, model );           
             
            
            String pKey = "";
            // Obten�ao das chaves prim�rias das tabelas envolvidas
             Iterator it = auxiliary.iterator();
             while( it.hasNext())
             {   
                 if( className1.equals(it.next()))
                     pKey = (String)it.next();
                 else
                     it.next();
                               
             }              
             
                    
            // tratamento do relacionamento 1 para 1, e 1 para N
            if( ((!many1) && (!many2)) || ((!many1) && (many2))  ) 
            { 
                // Neste caso, a tabela da classe className1 exporta o campo para a classe className2
                terraDB.createRelation(className1, className1, className2, pKey);           
            }
             
            // tratamento do restante do relacionamento 1 para N
            else if(many1 && (!many2))
            {
                // Neste caso, a tabela da classe className2 exporta o campo para a classe className1
                terraDB.createRelation(className2, className2, className1, pKey);                
            }
             
            // tratamento do relacionamento M para N
            else
            {
                String pKey2 = "";
                it = auxiliary.iterator();
                while( it.hasNext())
                {   
                   if( className2.equals(it.next()))
                       pKey2 = (String)it.next();
                   else
                      it.next();
                }
                if( pKey.equals(""))
                    pKey = "object_id_";
                if( pKey2.equals(""))
                    pKey2 = "object_id_";
                          
                terraDB.createTable(className1, className2, pKey, pKey2 );
                
            }
            
        
       }
    }
  }
  
  
  
  // este m�todo l� e retorna o conte�do (texto) de uma tag (elemento)
  // filho da tag informada como par�metro. A tag filho a ser pesquisada
  // � a tag informada pelo nome (string)
  public static String getChildTagValue( Element elem, String tagName ) throws Exception { // voltar para private depois
    NodeList children = elem.getElementsByTagName( tagName );
    if( children == null ) return null;
    Element child = (Element) children.item(0);
    if( child == null ) return null;
    return child.getFirstChild().getNodeValue();
  }
  
  private boolean checkRepresentation( final Element e, String isRep )
  {
        NodeList isReps = e.getElementsByTagName( "Foundation.Core.GeneralizableElement." + isRep );
        Element isR = (Element)isReps.item(0);
        String resposta = isR.getAttribute("xmi.value");
        if( resposta.equals("true") )// objeto possui representa�ao de pol�gono
            return true;
        else 
            return false;             
  }
  
  private String getType( Element model, String id )
  {
      NodeList dataTypes = model.getElementsByTagName( "Foundation.Core.DataType" );
      
      for( int i = 0; i < dataTypes.getLength(); i++ )
      {
          Element dataType = (Element)dataTypes.item(i);
          String resultID = dataType.getAttribute("xmi.id");
          try{
          if( resultID.equals(id))
          {
            String s = getChildTagValue(dataType, "Foundation.Core.ModelElement.name" );
            if (s != null)
               return s;
      
          }
          }
          catch( Exception e )
          {
              System.out.println("Exce�ao ao se tentar achar o tipo!");
          }
     }
      
      dataTypes = model.getElementsByTagName( "Foundation.Core.Class" );
      
      for( int i = 0; i < dataTypes.getLength(); i++ )
      {
          Element dataType = (Element)dataTypes.item(i);
          String resultID = dataType.getAttribute("xmi.id");
          try{
          if( resultID.equals(id))
          {
            String s = getChildTagValue(dataType, "Foundation.Core.ModelElement.name" );
            if (s != null)
               return s;
      
          }
          }
          catch( Exception e )
          {
              System.out.println("Exce�ao ao se tentar achar o tipo!");
          }
     }
      return null;
      
  }
  
  public String[] decideRepresentation(String parentClass, String[] desc, Element pack ) throws Exception
  {      
      
       boolean isPoint = false, isLine = false, isPolygon = false, isComplexObj = false;
     
      NodeList geoobjs = pack.getElementsByTagName("Foundation.Core.GeographicObject");
      NodeList ngeoobjs = pack.getElementsByTagName("Foundation.Core.NonGeographicObject");
      NodeList geofields = pack.getElementsByTagName("Foundation.Core.GeographicField");
      
      String representation[] = new String[4];
      
      for( int i = 0; i < geoobjs.getLength(); i++ )
      {
          
                Element geoobj = (Element)geoobjs.item(i); 
                String name = getChildTagValue( geoobj, "Foundation.Core.ModelElement.name" );                
                
                 if (parentClass.equals(name))
                 { 
                            
                            isPoint = (isPoint || checkRepresentation( geoobj, "isPoint"));
                            isLine = (isLine || checkRepresentation( geoobj, "isLine"));
                            isPolygon = (isPolygon || checkRepresentation( geoobj, "isPolygon"));
                            isComplexObj = (isComplexObj || checkRepresentation( geoobj, "isComplexObj" ));
                            
                  }
                  for( int b = 0; b < desc.length; b++ )
                    {
                        if (desc[b].equals(name))
                        {   
                            
                             isPoint = (isPoint || checkRepresentation( geoobj, "isPoint"));
                            isLine = (isLine || checkRepresentation( geoobj, "isLine"));
                            isPolygon = (isPolygon || checkRepresentation( geoobj, "isPolygon"));
                            isComplexObj = (isComplexObj || checkRepresentation( geoobj, "isComplexObj" ));
                            
                            
                        }
                    }     
              
            
      }
      
      for( int i = 0; i < ngeoobjs.getLength(); i++ )
      {
          
                Element ngeoobj = (Element)ngeoobjs.item(i); 
                String name = getChildTagValue( ngeoobj, "Foundation.Core.ModelElement.name" );

                        
                
                
                 if (parentClass.equals(name))
                 {
                            
                            isPoint = (isPoint || checkRepresentation( ngeoobj, "isPoint"));
                            isLine = (isLine || checkRepresentation( ngeoobj, "isLine"));
                            isPolygon = (isPolygon || checkRepresentation( ngeoobj, "isPolygon"));
                            isComplexObj = (isComplexObj || checkRepresentation( ngeoobj, "isComplexObj" ));
                            
                            
                  }
                  for( int b = 0; b < desc.length; b++ )
                    {
                        if (desc[b].equals(name))
                        {
                            
                             isPoint = (isPoint || checkRepresentation( ngeoobj, "isPoint"));
                            isLine = (isLine || checkRepresentation( ngeoobj, "isLine"));
                            isPolygon = (isPolygon || checkRepresentation( ngeoobj, "isPolygon"));
                            isComplexObj = (isComplexObj || checkRepresentation( ngeoobj, "isComplexObj" ));
                            
                            
                        }
                    }     
              
            
      }
      
      for( int i = 0; i < geofields.getLength(); i++ )
      {
          
                Element geofield = (Element)geofields.item(i); 
                String name = getChildTagValue( geofield, "Foundation.Core.ModelElement.name" );

                        
                
                
                 if (parentClass.equals(name))
                 {
                            
                             isPoint = (isPoint || checkRepresentation( geofield, "isPoint"));
                            isLine = (isLine || checkRepresentation( geofield, "isLine"));
                            isPolygon = (isPolygon || checkRepresentation( geofield, "isPolygon"));
                            isComplexObj = (isComplexObj || checkRepresentation( geofield, "isComplexObj" ));
                            
                            
                  }
                  for( int b = 0; b < desc.length; b++ )
                    {
                        if (desc[b].equals(name))
                        {
                            
                             isPoint = (isPoint || checkRepresentation( geofield, "isPoint"));
                            isLine = (isLine || checkRepresentation( geofield, "isLine"));
                            isPolygon = (isPolygon || checkRepresentation( geofield, "isPolygon"));
                            isComplexObj = (isComplexObj || checkRepresentation( geofield, "isComplexObj" ));
                            
                            
                        }
                    }                  
            
      }
      
      representation[0] = representation[1]= representation[2]= representation[3] = "";
             
       if (isPoint) representation[0] = "Ponto";
       if (isLine)  representation[1] = "Linha";
       if (isPolygon) representation[2] = "Pol";
       if (isComplexObj) representation[3] = "Complex";
      
      return representation; 
      
      
  }
  
  
  // dado o nome de uma classe, retorna sua chave prim�ria
  public String getPrimaryKey( String parentClass, Element pack ) throws Exception
  {
      
      NodeList geoobjs = pack.getElementsByTagName("Foundation.Core.GeographicObject");
      NodeList ngeoobjs = pack.getElementsByTagName("Foundation.Core.NonGeographicObject");
      NodeList geofields = pack.getElementsByTagName("Foundation.Core.GeographicField");
      
      for( int i = 0; i < geoobjs.getLength(); i++ )
      {
          
            Element geoobj = (Element)geoobjs.item(i); 
            String name = getChildTagValue( geoobj, "Foundation.Core.ModelElement.name" );
            
            if( !(parentClass.equals(name)) )
                continue;
            else
            {

                   // atributos
                   NodeList attributes = geoobj.getElementsByTagName( "Foundation.Core.Attribute" );
                   String primaryKey = "";      


                 for( int j = 0; j < attributes.getLength(); j++ )
                 {

                       Element attr = (Element)attributes.item(j);
                       // nome do atributo
                       String attributeName = getChildTagValue( attr, "Foundation.Core.ModelElement.name" );


                       NodeList structFields = attr.getElementsByTagName("Foundation.Core.StructuralFeature.type");
                       Element structType = (Element)structFields.item(0);

                       NodeList classifiers = structType.getElementsByTagName( "Foundation.Core.Classifier" );
                       Element classify = (Element)classifiers.item(0);

                      // chave prim�ria ou n�o
                       boolean pKey = false;
                       NodeList pKeys = geoobj.getElementsByTagName( "Foundation.Extension_Mechanisms.TaggedValue" );
                       for( int k = 0; k < pKeys.getLength(); k++ )
                       {       

                           Element temp = (Element)pKeys.item(k);
                           String teste = getChildTagValue( temp, "Foundation.Extension_Mechanisms.TaggedValue.tag" );
                           String teste2 = getChildTagValue(temp, "Foundation.Extension_Mechanisms.TaggedValue.value");
                           if (teste.equals("primary key")&& teste2.equals("true") )
                           {
                               pKey = true;
                           }
                       }

                       if( pKey ) 
                       {
                           primaryKey = attributeName;
                           return primaryKey;
                       }
                   }
                   
                   return primaryKey;
            }
           
           
      }
      
      for( int i = 0; i < ngeoobjs.getLength(); i++ )
      {
          
            Element ngeoobj = (Element)ngeoobjs.item(i); 
            String name = getChildTagValue( ngeoobj, "Foundation.Core.ModelElement.name" );
            
              if( !(parentClass.equals(name)) )
                continue;
            else
            {

                   // atributos
                   NodeList attributes = ngeoobj.getElementsByTagName( "Foundation.Core.Attribute" );
                   String primaryKey = "";      


                 for( int j = 0; j < attributes.getLength(); j++ )
                 {

                       Element attr = (Element)attributes.item(j);
                       // nome do atributo
                       String attributeName = getChildTagValue( attr, "Foundation.Core.ModelElement.name" );


                       NodeList structFields = attr.getElementsByTagName("Foundation.Core.StructuralFeature.type");
                       Element structType = (Element)structFields.item(0);

                       NodeList classifiers = structType.getElementsByTagName( "Foundation.Core.Classifier" );
                       Element classify = (Element)classifiers.item(0);

                      // chave prim�ria ou n�o
                       boolean pKey = false;
                       NodeList pKeys = ngeoobj.getElementsByTagName( "Foundation.Extension_Mechanisms.TaggedValue" );
                       for( int k = 0; k < pKeys.getLength(); k++ )
                       {       

                           Element temp = (Element)pKeys.item(k);
                           String teste = getChildTagValue( temp, "Foundation.Extension_Mechanisms.TaggedValue.tag" );
                           String teste2 = getChildTagValue(temp, "Foundation.Extension_Mechanisms.TaggedValue.value");
                           if (teste.equals("primary key")&& teste2.equals("true") )
                           {
                               pKey = true;
                           }
                       }

                       if( pKey ) primaryKey = attributeName;
                   }
                   
                   return primaryKey;
            }
           
           
      }
      
      for( int i = 0; i < geofields.getLength(); i++ )
      {
          
            Element geofield = (Element)geofields.item(i); 
            String name = getChildTagValue( geofield, "Foundation.Core.ModelElement.name" );
            
              if( !(parentClass.equals(name)) )
                continue;
            else
            {

                   // atributos
                   NodeList attributes = geofield.getElementsByTagName( "Foundation.Core.Attribute" );
                   String primaryKey = "";      


                 for( int j = 0; j < attributes.getLength(); j++ )
                 {

                       Element attr = (Element)attributes.item(j);
                       // nome do atributo
                       String attributeName = getChildTagValue( attr, "Foundation.Core.ModelElement.name" );


                       NodeList structFields = attr.getElementsByTagName("Foundation.Core.StructuralFeature.type");
                       Element structType = (Element)structFields.item(0);

                       NodeList classifiers = structType.getElementsByTagName( "Foundation.Core.Classifier" );
                       Element classify = (Element)classifiers.item(0);

                      // chave prim�ria ou n�o
                       boolean pKey = false;
                       NodeList pKeys = geofield.getElementsByTagName( "Foundation.Extension_Mechanisms.TaggedValue" );
                       for( int k = 0; k < pKeys.getLength(); k++ )
                       {       

                           Element temp = (Element)pKeys.item(k);
                           String teste = getChildTagValue( temp, "Foundation.Extension_Mechanisms.TaggedValue.tag" );
                           String teste2 = getChildTagValue(temp, "Foundation.Extension_Mechanisms.TaggedValue.value");
                           if (teste.equals("primary key")&& teste2.equals("true") )
                           {
                               pKey = true;
                           }
                       }

                       if( pKey ) primaryKey = attributeName;
                   }
                   
                   return primaryKey;
            }
                      
      } 
      
      String vazia = "";
      return vazia;
      
  }
  
  public List getAttributeList( String parentClass, Element pack, boolean p ) throws Exception
  {
      
      NodeList geoobjs = pack.getElementsByTagName("Foundation.Core.GeographicObject");
      NodeList ngeoobjs = pack.getElementsByTagName("Foundation.Core.NonGeographicObject");
      NodeList geofields = pack.getElementsByTagName("Foundation.Core.GeographicField");
      
      List myAttributes = new ArrayList(); 
   
      
      for( int i = 0; i < geoobjs.getLength(); i++ )
      {
          
            Element geoobj = (Element)geoobjs.item(i); 
            String name = getChildTagValue( geoobj, "Foundation.Core.ModelElement.name" );
            
            if( !(parentClass.equals(name)) )
                continue;
            else
            {

                   // atributos
                   NodeList attributes = geoobj.getElementsByTagName( "Foundation.Core.Attribute" );
                   String primaryKey = "";      


                 for( int j = 0; j < attributes.getLength(); j++ )
                 {

                       Element attr = (Element)attributes.item(j);
                       // nome do atributo
                       String attributeName = getChildTagValue( attr, "Foundation.Core.ModelElement.name" );
                    
                      // chave prim�ria ou n�o
                       boolean pKey = false;
                       NodeList pKeys = attr.getElementsByTagName( "Foundation.Extension_Mechanisms.TaggedValue" );
                       for( int k = 0; k < pKeys.getLength(); k++ )
                       {       

                           Element temp = (Element)pKeys.item(k);
                           String teste = getChildTagValue( temp, "Foundation.Extension_Mechanisms.TaggedValue.tag" );
                           String teste2 = getChildTagValue(temp, "Foundation.Extension_Mechanisms.TaggedValue.value");
                           if (teste.equals("primary key")&& teste2.equals("true") )
                           {  
                               pKey = true;
                           }
                       }

                       if( p )
                       {
                           
                           if( pKey )
                           {  
                               pKey = false;
                               continue;
                           }
                       }
                        myAttributes.add( attributeName );

                   }
                   
                
                 return myAttributes;
            }
           
           
      }
      
      for( int i = 0; i < ngeoobjs.getLength(); i++ )
      {
          
            Element ngeoobj = (Element)ngeoobjs.item(i); 
            String name = getChildTagValue( ngeoobj, "Foundation.Core.ModelElement.name" );
            
              if( !(parentClass.equals(name)) )
                continue;
            else
            {

                   // atributos
                   NodeList attributes = ngeoobj.getElementsByTagName( "Foundation.Core.Attribute" );
                   String primaryKey = "";      


                 for( int j = 0; j < attributes.getLength(); j++ )
                 {

                       Element attr = (Element)attributes.item(j);
                       // nome do atributo
                       String attributeName = getChildTagValue( attr, "Foundation.Core.ModelElement.name" );
                      

                       NodeList structFields = attr.getElementsByTagName("Foundation.Core.StructuralFeature.type");
                       Element structType = (Element)structFields.item(0);

                       NodeList classifiers = structType.getElementsByTagName( "Foundation.Core.Classifier" );
                       Element classify = (Element)classifiers.item(0);

                      // chave prim�ria ou n�o
                       boolean pKey = false;
                       NodeList pKeys = ngeoobj.getElementsByTagName( "Foundation.Extension_Mechanisms.TaggedValue" );
                       for( int k = 0; k < pKeys.getLength(); k++ )
                       {       

                           Element temp = (Element)pKeys.item(k);
                           String teste = getChildTagValue( temp, "Foundation.Extension_Mechanisms.TaggedValue.tag" );
                           String teste2 = getChildTagValue(temp, "Foundation.Extension_Mechanisms.TaggedValue.value");
                           if (teste.equals("primary key")&& teste2.equals("true") )
                           {
                               pKey = true;
                           }
                       }

                           if( p )
                       {
                           
                           if( pKey ) continue;
                       }
                        myAttributes.add( attributeName );
                   }
                   
                  return myAttributes;
            }
           
           
      }
      
      for( int i = 0; i < geofields.getLength(); i++ )
      {
          
            Element geofield = (Element)geofields.item(i); 
            String name = getChildTagValue( geofield, "Foundation.Core.ModelElement.name" );
            
              if( !(parentClass.equals(name)) )
                continue;
            else
            {

                   // atributos
                   NodeList attributes = geofield.getElementsByTagName( "Foundation.Core.Attribute" );
                   String primaryKey = "";      


                 for( int j = 0; j < attributes.getLength(); j++ )
                 {

                       Element attr = (Element)attributes.item(j);
                       // nome do atributo
                       String attributeName = getChildTagValue( attr, "Foundation.Core.ModelElement.name" );
                     

                       NodeList structFields = attr.getElementsByTagName("Foundation.Core.StructuralFeature.type");
                       Element structType = (Element)structFields.item(0);

                       NodeList classifiers = structType.getElementsByTagName( "Foundation.Core.Classifier" );
                       Element classify = (Element)classifiers.item(0);

                      // chave prim�ria ou n�o
                       boolean pKey = false;
                       NodeList pKeys = geofield.getElementsByTagName( "Foundation.Extension_Mechanisms.TaggedValue" );
                       for( int k = 0; k < pKeys.getLength(); k++ )
                       {       

                           Element temp = (Element)pKeys.item(k);
                           String teste = getChildTagValue( temp, "Foundation.Extension_Mechanisms.TaggedValue.tag" );
                           String teste2 = getChildTagValue(temp, "Foundation.Extension_Mechanisms.TaggedValue.value");
                           if (teste.equals("primary key")&& teste2.equals("true") )
                           {
                               pKey = true;
                           }
                       }

                           if( p )
                       {
                           
                           if( pKey ) continue;
                       }
                        myAttributes.add( attributeName );
                   }
                   
                  return myAttributes;
            }
                      
      } 
      
     throw new Exception("erro legal");
      
  }
  
  
  // retorna lista de descendentes de uma determinada classe
  public List getDescendant( String parentClass, Element pack ) throws Exception
  {
      
      NodeList geoobjs = pack.getElementsByTagName("Foundation.Core.GeographicObject");
      NodeList ngeoobjs = pack.getElementsByTagName("Foundation.Core.NonGeographicObject");
      NodeList geofields = pack.getElementsByTagName("Foundation.Core.GeographicField");
      
      List result = new ArrayList();
      
      for( int i = 0; i < geoobjs.getLength(); i++ )
      {
          
          Element geoobj = (Element) geoobjs.item(i);
          
          String name = getChildTagValue( geoobj, "Foundation.Core.ModelElement.name" );
          if( parentClass.equals(name))
          {
              NodeList list = geoobj.getElementsByTagName("Foundation.Core.Generalization");
              for( int j = 0; j < list.getLength(); j++)
              {
                  Element gen  = (Element) list.item(j);
                  String idRef = gen.getAttribute("xmi.idref");
                  String child = getChild(idRef, pack );
                  String childClass = getClassName2(child, pack);
                  result.add(childClass);                  
              }   
              
          }
      }
      
      for( int i = 0; i < ngeoobjs.getLength(); i++ )
      {
          
          Element ngeoobj = (Element) ngeoobjs.item(i);
          
          String name = getChildTagValue( ngeoobj, "Foundation.Core.ModelElement.name" );
          if( parentClass.equals(name))
          {
              NodeList list = ngeoobj.getElementsByTagName("Foundation.Core.Generalization");
              for( int j = 0; j < list.getLength(); j++)
              {
                  Element gen  = (Element) list.item(j);
                  String idRef = gen.getAttribute("xmi.idref");
                  String childClass = getClassName2(idRef, pack);
                  result.add(childClass);                  
              }   
              
          }
      }
      
      for( int i = 0; i < geofields.getLength(); i++ )
      {
          
          Element geofield = (Element) geofields.item(i);
          
          String name = getChildTagValue( geofield, "Foundation.Core.ModelElement.name" );
          if( parentClass.equals(name))
          {
              NodeList list = geofield.getElementsByTagName("Foundation.Core.Generalization");
              for( int j = 0; j < list.getLength(); j++)
              {
                  Element gen  = (Element) list.item(j);
                  String idRef = gen.getAttribute("xmi.idref");
                  String childClass = getClassName2(idRef, pack);
                  result.add(childClass);                  
              }   
              
          }
      }
      
      return result;    
       
  }      
      
      
  public String getChild( String idRef, Element pack )
  {
      NodeList generalizations = pack.getElementsByTagName("Foundation.Core.Generalization");
      for( int i = 0; i < generalizations.getLength(); i++ )
      {
          Element generalization = (Element)generalizations.item(i);
          String attr = generalization.getAttribute("xmi.id");
          if( attr.equals(idRef))
          {
                NodeList children = generalization.getElementsByTagName("Foundation.Core.GeneralizableElement");
                Element child = (Element) children.item(0);
                String id = child.getAttribute("xmi.idref");
                return id;             
          }
          else
              continue;
      }
      
      return "erro!!!";
  }
      
  // obt�m a multiplicidade de determinado elemento
  // true para muitos e false caso contr�rio
  public boolean getMultiplicity( Element multiplicity, Element elem )
  {     
          
     String inferior = "", superior = "";
     try
     {
       inferior = getChildTagValue( multiplicity, "Foundation.Data_Types.MultiplicityRange.lower");
       superior = getChildTagValue( multiplicity, "Foundation.Data_Types.MultiplicityRange.upper");
     }
     catch( Exception e )
     {
         System.out.println("Multiplicidade com problemas!");
     }
  
      if( inferior == null)
      {
          NodeList l = multiplicity.getElementsByTagName("Foundation.Data_Types.Multiplicity");
          Element e = (Element)l.item(0);
          String ref = e.getAttribute("xmi.idref");       
          return searchID(ref, elem);         
      }    
      else
      {
          if ( superior.equals("-1"))
              return true;
          else
              return false; 
          
      }    
      
  }

  // Dado o ID, retorna o nome da classe
  public String getClassName2( String idRef, Element pack ) throws Exception
  {
      
      NodeList geoobjs = pack.getElementsByTagName("Foundation.Core.GeographicObject");
      NodeList ngeoobjs = pack.getElementsByTagName("Foundation.Core.NonGeographicObject");
      NodeList geofields = pack.getElementsByTagName("Foundation.Core.GeographicField");
      
     
      for( int i = 0; i < geoobjs.getLength(); i++ )
      {
          Element geoobj = (Element) geoobjs.item(i);
          String attr = geoobj.getAttribute("xmi.id");
       
          if( idRef.equals(attr))
          {
              String className = getChildTagValue( geoobj, "Foundation.Core.ModelElement.name" );
              return className;
          }         
      }
      
      for( int i = 0; i < ngeoobjs.getLength(); i++ )
      {
          Element ngeoobj = (Element) ngeoobjs.item(i);
          String attr = ngeoobj.getAttribute("xmi.id"); System.out.println("ids que encontro: " + attr );
          if( idRef.equals(attr))
          { 
              String className = getChildTagValue( ngeoobj, "Foundation.Core.ModelElement.name" );
              return className;
          }         
      }
      
      for( int i = 0; i < geofields.getLength(); i++ )
      {
          Element geofield = (Element) geofields.item(i);
          String attr = geofield.getAttribute("xmi.id"); System.out.println("ids que encontro: " + attr );
          if( idRef.equals(attr))
          { 
              String className = getChildTagValue( geofield, "Foundation.Core.ModelElement.name" );
              return className;
          }         
      }    
      
      return "erro";
  }
  
  
  public String getClassName1( Element relation, Element pack ) throws Exception
  {
       NodeList classifiers = relation.getElementsByTagName("Foundation.Core.Classifier");
       Element classifier = (Element)classifiers.item(0);
       String idref = classifier.getAttribute("xmi.idref");
       
       //pesquisa nas classes de objetos geogr�ficos
       NodeList geoobjs = pack.getElementsByTagName( "Foundation.Core.GeographicObject" );
       //pesquisa nas classes de objetos n�o-geogr�ficos
       NodeList ngeoobjs = pack.getElementsByTagName( "Foundation.Core.NonGeographicObject" );
       // pesquisa nas classes de campos geogr�ficos
       NodeList geofields = pack.getElementsByTagName( "Foundation.Core.GeographicField" );
       
       if( geoobjs.getLength() > 0)
       {
          
           for( int i = 0; i < geoobjs.getLength(); i++ )
           {
                Element geoobj = (Element) geoobjs.item(i);
                String attribute = geoobj.getAttribute("xmi.id");
                if( attribute.equals(idref))
                {
                    String className = getChildTagValue( geoobj, "Foundation.Core.ModelElement.name" );
                    return className;
                                
                }
           }
       }
       
       if( ngeoobjs.getLength() > 0)
       {
          
           for( int i = 0; i < ngeoobjs.getLength(); i++ )
           {
                Element ngeoobj = (Element) ngeoobjs.item(i);
                String attribute = ngeoobj.getAttribute("xmi.id");
                if( attribute.equals(idref))
                {
                    String className = getChildTagValue( ngeoobj, "Foundation.Core.ModelElement.name" );
                    return className;
                                
                }
           }
       }
       
       if( geofields.getLength() > 0)
       {
          
           for( int i = 0; i < geofields.getLength(); i++ )
           {
                Element geofield = (Element) geofields.item(i);
                String attribute = geofield.getAttribute("xmi.id");
                if( attribute.equals(idref))
                {
                    String className = getChildTagValue( geofield, "Foundation.Core.ModelElement.name" );
                    return className;
                                
                }
           }
       }
       
       throw new Exception("Erro!!!!!!!!!!");
       
           
      
      
  }
  
  public boolean searchID( String ref, Element elem )
  {
      
      NodeList list = elem.getElementsByTagName("Foundation.Data_Types.Multiplicity");
      String value = "";
      
      try
          {
          for( int i = 0; i < list.getLength(); i++ )
          {

              Element e = (Element)list.item(i);
              String attr = e.getAttribute("xmi.id");
              if( ref.equals(attr))
              {
                  value = getChildTagValue(e, "Foundation.Data_Types.MultiplicityRange.upper");

              }

          }
      }
      
      catch(Exception e)
      {
          System.out.println("Deu erro!");
          
          
      }
      
      return (value.equals("-1"));     
      
  }

  
  public static void main( String args[] )
  {
      String s = "file:///C:\\Documents and Settings\\Usuario\\Desktop\\genera.xmi"; //relacao.xmi";  //repolho.xmi"; //assoc.xmi";
      XmlReader app = new XmlReader (s);
      try
      {
         app.lerXMI();
   
      }
      catch( Exception e )
      {
          System.err.println("Error reading xmi file!");
          System.exit(1);
      }
  }
 
}

// classe para armazenar tipos de dados e classes criadas no diagrama
class DataType
{
    private String id;
    private String name;
    
    public DataType( String id, String name )
    {
        this.id = id;
        this.name = name;
    }
    
    public void setId( String id )
    {
        this.id = id;
    }
    public void setName( String name )
    {
        this.name = name;
    }
    public String getId()
    {
        return id;
    }
    public String getName()
    {
        return name;
    }
    public String toString()
    {
        String s = "Name " + name + "\n" + "ID: " + id;
        return s;
    }
}